import json
from datetime import datetime

from flask import Flask, render_template, request, redirect, session, send_file, flash, jsonify
import psycopg2
from collections.abc import Iterable
import os
from werkzeug.utils import secure_filename
from difflib import SequenceMatcher

def flatten(lis):
    for item in lis:
        if isinstance(item, Iterable) and not isinstance(item, str):
            for x in flatten(item):
                yield x
        else:
            yield item


conn = psycopg2.connect(dbname="lapar", user="dok", password="34686V", host="localhost")
cursor = conn.cursor()
cursor.execute("ROLLBACK")
conn.commit()


class NewAshka:
    def __init__(self):
        self.name = None
        self.cost = None
        self.maker = None
        self.puffs = None
        self.num = None
        self.flavours = None
        self.akkum = None
        self.weight = None
        self.new = None


class NewPod:
    def __init__(self):
        self.name = None
        self.cost = None
        self.maker = None
        self.num = None
        self.path = None
        self.maxw = None
        self.akkum = None
        self.weight = None
        self.new = None


class NewLiq:
    def __init__(self):
        self.name = None
        self.cost = None
        self.maker = None
        self.pv = None
        self.num = None
        self.flavours = None
        self.weight = None
        self.new = None
        self.mg = None


class CustomFlask(Flask):
    jinja_options = Flask.jinja_options.copy()
    jinja_options.update(
        dict(
            block_start_string="<%",
            block_end_string="%>",
            variable_start_string="%%",
            variable_end_string="%%",
            comment_start_string="<#",
            comment_end_string="#>",
        )
    )


app = CustomFlask(__name__)
name = "name"
app.secret_key = "app secret key"
password = '1234'

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}
direction = os.getcwd()
UPLOAD_FOLDER = f'{direction}/backgrounds'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

#
# def allowed_file(filename):
#     return '.' in filename and \
#            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def upload_file(request):
    if request.method == 'POST':
        if 'path' not in request.files:
            flash('Нет фотографии')
            return redirect(request.url)
        file = request.files['path']
        if file.filename == '':
            flash('Не выбран файл')
            return redirect(request.url)
        if file:
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))


@app.route("/login", methods=['POST', 'GET'])
def login():
    global password
    if request.method == 'GET':
        return '<form action="/login" method="post"><input name= password>Введите пароль</input></form>'
    else:
        if request.form.get('password') == password:
            session['admin'] = True
            return redirect('/')
        else:
            return redirect('/login')


@app.route("/<category>/add_item", methods=['POST', 'GET'])
def new_item(category):
    if request.method == 'GET':
        if session['admin']:
            return render_template('add_item.html', category=category)
        else:
            return 'У вас нет прав администратора'
    else:
        if not session['admin']:
            return "У вас нет прав администратора"
        if category == 'pods':
            pod = NewPod()
            pod.name = request.form.get('name')
            pod.cost = request.form.get('cost')
            pod.maker = request.form.get('maker')
            pod.value = request.form.get('value')
            pod.path = request.files['path'].filename
            pod.maxw = request.form.get('maxw')
            pod.weight = request.form.get('weight')
            pod.akkum = request.form.get('akkum')
            pod.new = request.form.get('new')
            if pod.new == 'on':
                pod.new = True
            if pod.new != 'on' and not pod.new:
                pod.new = False
            upload_file(request)
            data = (pod.maker, pod.name, "pods", pod.cost, pod.value, False, pod.path, pod.maxw, pod.weight, pod.akkum, pod.new)
            cursor.execute(
                'INSERT INTO items  (maker, item, category, cost, value, "isSpecial", path, maxw, weight, akkum, "isNew") VALUES(%s,%s,%s,%s,%s,%s, %s, %s, %s, %s, %s)',
                data)
            conn.commit()
        elif category == 'esigs':
            ashka = NewAshka()
            ashka.name = request.form.get('name')
            ashka.cost = request.form.get('cost')
            ashka.maker = request.form.get('maker')
            ashka.value = request.form.get('value')
            ashka.path = request.files['path'].filename
            ashka.weight = request.form.get('weight')
            ashka.akkum = request.form.get('akkum')
            ashka.new = request.form.get('new')
            ashka.flavours = request.form.get('flavours')
            ashka.puffs = request.form.get('puffs')
            if ashka.new == 'on':
                ashka.new = True
            if ashka.new != 'on' or not ashka.new:
                ashka.new = False
            upload_file(request)
            for i in ashka.flavours.split(','):
                data = (
                    ashka.name, ashka.cost, "ashki", ashka.maker, ashka.value, False, ashka.puffs, i, ashka.path, ashka.weight, ashka.akkum, ashka.new)
                cursor.execute(
                    'INSERT INTO items  (item, cost, category, maker, value, "isSpecial", puffs, flavour, path,  weight, akkum, "isNew") VALUES(%s,%s,%s,%s,%s,%s,%s, %s, %s, %s, %s, %s)',
                    data)
                conn.commit()
        elif category == 'liq':
            liq = NewLiq()
            liq.name = request.form.get('name')
            liq.cost = request.form.get('cost')
            liq.maker = request.form.get('maker')
            liq.value = request.form.get('value')
            liq.path = request.files['path'].filename
            liq.weight = request.form.get('weight')
            liq.new = request.form.get('new')
            liq.flavours = request.form.get('flavours')
            liq.pv = request.form.get('pv')
            liq.mg = request.form.get('mg')
            if liq.new == 'on':
                liq.new = True
            if liq.new != 'on' or not liq.new:
                liq.new = False
            upload_file(request)
            for i in liq.flavours.split(','):
                data = (
                    liq.name, liq.cost, "liq", liq.maker, liq.value, False, liq.pv,liq.mg, i, liq.path, liq.weight, liq.new)
                cursor.execute(
                    'INSERT INTO items  (item, cost, category, maker, value, "isSpecial", pv, mg, flavour, path,  weight, "isNew") VALUES(%s,%s,%s,%s,%s,%s, %s, %s, %s, %s, %s, %s)',
                    data)
                conn.commit()
        elif category == 'coils':
            name = request.form.get('name')
            cost = request.form.get('cost')
            maker = request.form.get('maker')
            value = request.form.get('value')
            path = request.files['path'].filename
            resistance = request.form.get('resistance')
            devices = request.form.get('devices')
            upload_file(request)
            for i in resistance.split(","):
                data = (name, cost, maker, value, path, devices, i)
                cursor.execute('INSERT INTO coils (name, cost, maker,num, path, devices, resistance) VALUES (%s,%s,%s,%s,%s,%s, %s)', data)
                conn.commit()
        elif category == 'tobacco':
            name = request.form.get('name')
            cost = request.form.get('cost')
            maker = request.form.get('maker')
            value = request.form.get('value')
            path = request.files['path'].filename
            pv = request.form.get("pv")
            upload_file(request)
            flavours = request.form.get('flavours')
            data = (name, cost, maker, value, path, flavours, pv)
            for i in flavours.split(','):
                data = (
                    name, cost, "tobacco", maker, value, False, i, path, pv)
                cursor.execute(
                    'INSERT INTO items  (item, cost, category, maker, value, "isSpecial", flavour, path, pv) VALUES(%s,%s,%s,%s,%s,%s, %s, %s, %s)',
                    data)
                conn.commit()
        elif category == 'hookahs':
            name = request.form.get('name')
            cost = request.form.get('cost')
            maker = request.form.get('maker')
            value = request.form.get('value')
            path = request.files['path'].filename
            upload_file(request)
            data = (name, cost, "hookahs", maker, value, path)
            cursor.execute(
                'INSERT INTO items  (item, cost, category, maker, value, path) VALUES(%s,%s,%s,%s,%s,%s)',
                data)
            conn.commit()
        return redirect(f'/{category}')


@app.route('/tobacco/change/item/', methods=['POST', 'GET'])
def change_tobacco():
    if not session['admin']:
        return "У вас нет прав администратора"
    name = request.form.get('name')
    isNew = request.form.get('new')
    toexcec = ''
    if isNew == 'on':
        isNew = True
        toexcec += '"isNew" = True,'
    if isNew != 'on' and not isNew:
        isNew = False
    isSpecial = request.form.get('special')
    if isSpecial == 'on':
        isSpecial = True
        toexcec += '"isSpecial" = True,'
    if isSpecial != 'on' and not isSpecial:
        isSpecial = False
    isDelite = request.form.get('delite')
    if isDelite == 'on':
        isDelite = True
    if isDelite != 'on' and not isDelite:
        isDelite = False

    price = request.form.get('changeprice')
    value = request.form.get('changevalue')
    flavour = request.form.get('flavour')
    data = (price, value, name, flavour)
    print(data)
    if not isDelite:
        cursor.execute("SELECT cost from items WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9",
                       (name, flavour))
        oldprice = cursor.fetchall()[0][0]
        data = (price, value, oldprice, name, flavour)
        cursor.execute('UPDATE items SET cost = cost + %s, value = value + %s,' + toexcec +
                       'oldprice=%s WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9', (data))
        conn.commit()
    else:
        cursor.execute('DELETE FROM items WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9',
                       (name, flavour))
        conn.commit()
    return redirect("/tobacco")



@app.route("/esigs/change/item/", methods=['POST', 'GET'])
def change_esigs():
    if not session['admin']:
        return "У вас нет прав администратора"
    name = request.form.get('name')
    isNew = request.form.get('new')
    toexcec = ''
    if isNew == 'on':
        isNew = True
        toexcec += '"isNew" = True,'
    if isNew != 'on' and not isNew:
        isNew = False
    isSpecial = request.form.get('special')
    if isSpecial == 'on':
        isSpecial = True
        toexcec += '"isSpecial" = True,'
    if isSpecial != 'on' and not isSpecial:
        isSpecial = False
    isDelite = request.form.get('delite')
    if isDelite == 'on':
        isDelite = True
    if isDelite != 'on' and not isDelite:
        isDelite = False

    price = request.form.get('changeprice')
    value = request.form.get('changevalue')
    flavour = request.form.get('flavour')
    data = (price, value, name, flavour)
    if not isDelite:
        cursor.execute("SELECT cost from items WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9", (name, flavour))
        oldprice = cursor.fetchall()[0][0]
        data = (price, value, oldprice, name, flavour)
        cursor.execute('UPDATE items SET cost = cost + %s, value = value + %s,' + toexcec +
                        'oldprice=%s WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9', (data))
        conn.commit()
    else:
        cursor.execute('DELETE FROM items WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9', (name, flavour))
        conn.commit()
    return redirect("/esigs")



@app.route("/liq/change/item/", methods=['POST', 'GET'])
def change_liq():
    if not session['admin']:
        return "У вас нет прав администратора"
    name = request.form.get('name')
    isNew = request.form.get('new')
    toexcec = ''
    if isNew == 'on':
        isNew = True
        toexcec += '"isNew" = True,'
    if isNew != 'on' and not isNew:
        isNew = False
    isSpecial = request.form.get('special')
    if isSpecial == 'on':
        isSpecial = True
        toexcec += '"isSpecial" = True,'
    if isSpecial != 'on' and not isSpecial:
        isSpecial = False
    isDelite = request.form.get('delite')
    if isDelite == 'on':
        isDelite = True
    if isDelite != 'on' and not isDelite:
        isDelite = False

    price = request.form.get('changeprice')
    value = request.form.get('changevalue')
    flavour = request.form.get('flavour')
    data = (price, value, isNew, isSpecial, name, flavour)
    if not isDelite:
        cursor.execute("SELECT cost from items WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9", (name, flavour))
        oldprice = cursor.fetchall()[0][0]
        data = (price, value, oldprice, name, flavour)
        cursor.execute('UPDATE items SET cost = cost + %s, value = value + %s,' + toexcec
                       +'oldprice=%s WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9', (data))
        conn.commit()
    else:
        cursor.execute('DELETE FROM items WHERE similarity(item,%s) > 0.9 AND similarity(flavour,%s) > 0.9', (name, flavour))
        conn.commit()
    return redirect("/liq")

@app.route("/admin_panel", methods=["GET", "POST"])
def admin_panel():
    if session["admin"]:
        if request.method == "POST":
            fromdate, todate =  request.form.get("daterange").split(" - ")
            print(fromdate, todate)
            cursor.execute('SELECT * from sells WHERE "when" >= %s AND "when" <= %s ORDER BY "when"', (fromdate, todate))
        else:
            cursor.execute('SELECT * from sells ORDER BY "when"')
        r = [dict((cursor.description[i][0], value) \
                      for i, value in enumerate(row)) for row in cursor.fetchall()]
        name_to_normal = {
                "pod" : "Поды",
                "pods" : "Поды",
                "esigs": "Одноразки",
                "ashki" : "Одноразки",
                "liq" : "Жидкости",
                "coils" : "Испарители",
                "tobacco" : "Табак",
                "hookahs" : "Кальяны"
            }
            # first chart
        x_and_values = dict()
        for i in r:
            i["x"] = name_to_normal[i["category"]]
            del i["category"]
            i["value"] = i["cost"]
            del i["cost"]
            if i["x"] not in x_and_values.keys():
                x_and_values[i["x"]] = i["value"]
            else:
                x_and_values[i["x"]] += i["value"]
        colors = ["#CC8B86", "#7D4F50", "#D1BE9C", "#326273", "#5C9EAD", "#E39774", "#391463"]
        first_chart_data = list()
        c = 0
        for i in x_and_values.keys():
            first_chart_data.append({"x" : list(x_and_values.keys())[c], "value": x_and_values[list(x_and_values.keys())[c]], "fill": colors[c]})
            c += 1
        print(first_chart_data)
        # second chart
        x_and_values2 = dict()
        for i in r:
            i["x"] = i["when"]
            del i["when"]
            print(i["x"].strftime("%D:%M:%Y").split(":")[0])
            if i["x"].strftime("%D:%M:%Y").split(":")[0] not in x_and_values2.keys():
                x_and_values2[i["x"].strftime("%D:%M:%Y").split(":")[0]] = i["value"]
            else:
                x_and_values2[i["x"].strftime("%D:%M:%Y").split(":")[0]] += i["value"]
        colors = ["#CC8B86", "#7D4F50", "#D1BE9C", "#326273", "#5C9EAD", "#E39774", "#391463"]
        second_chart_data = list()
        c = 0
        for i in x_and_values2.keys():
            second_chart_data.append([list(x_and_values2.keys())[c], x_and_values2[list(x_and_values2.keys())[c]]])
            c += 1
        print(second_chart_data)
        zarabatok = sum(list(x_and_values.values()))
        return render_template("admin_panel.html", first_chart_data = json.dumps(first_chart_data, indent=4, sort_keys=True, default=str), second_chart_data = second_chart_data, zarabatok = zarabatok)


@app.route("/<category>/sell_item", methods=["GET", "POST"])
def sell(category):
    name = request.form.get('name')
    print(name)
    flav = request.form.get('flavour')
    category1 = category
    if category == "esigs":
        category1 == "ashki"
    if category not in ["pods", "coils", "hookahs"]:
        cursor.execute("UPDATE items SET value = value-1 WHERE SIMILARITY(item,%s) > 0.9 AND SIMILARITY(flavour,%s) > 0.9",
                       (name,flav))
        conn.commit()
        cursor.execute('SELECT * FROM items WHERE SIMILARITY(item,%s) > 0.9 AND SIMILARITY(flavour,%s) > 0.9',
                       (name, flav))
        records = cursor.fetchall()
        cursor.execute('INSERT INTO sells (category, cost, "when") VALUES (%s,%s,%s)',
                       (category1, records[0][1], datetime.now()))
        conn.commit()
    else:
        cursor.execute('UPDATE items SET value = value-1 WHERE id = %s',
                       (int(name),))
        conn.commit()

        cursor.execute('SELECT * FROM items WHERE id = %s',
                       (name,))
        print('SELECT * FROM items WHERE id = %s',
                       (name,))
        records = cursor.fetchall()
        cursor.execute('INSERT INTO sells (category, cost, "when") VALUES (%s,%s,%s)',
                       (category1, records[0][1], datetime.now()))
        conn.commit()
    return redirect(f'/{category}')


@app.route("/hookahs/change/item/", methods=["POST", "GET"])
def change_hookah():
        if not session['admin']:
            return "У вас нет прав администратора"
        name = request.form.get('name')
        isNew = request.form.get('new')
        toexcec = ''
        if isNew == 'on':
            isNew = True
            toexcec += '"isNew" = True,'
        if isNew != 'on' and not isNew:
            isNew = False
        isSpecial = request.form.get('special')
        if isSpecial == 'on':
            isSpecial = True
            toexcec += '"isSpecial" = True,'
        if isSpecial != 'on' and not isSpecial:
            isSpecial = False
        isDelite = request.form.get('delite')
        if isDelite == 'on':
            isDelite = True
        if isDelite != 'on' and not isDelite:
            isDelite = False

        price = request.form.get('changeprice')
        value = request.form.get('changevalue')
        data = (price, value, isNew, isSpecial, name)
        if not isDelite:
            cursor.execute("SELECT cost from items WHERE id=%s", (data[4],))
            oldprice = cursor.fetchall()[0][0]
            data = (price, value, oldprice, name)
            cursor.execute('UPDATE items SET cost = cost + %s, value = value + %s,' + toexcec +
                           'oldprice=%s WHERE id= %s', (data))
            conn.commit()
        else:
            cursor.execute('DELETE FROM items WHERE id=%s', (name,))
            conn.commit()

        return redirect("/hookahs")


@app.route("/pods/change/item/", methods=['POST', 'GET'])
def change_pod():
    if not session['admin']:
        return "У вас нет прав администратора"
    name = request.form.get('name')
    isNew = request.form.get('new')
    toexcec = ''
    if isNew == 'on':
        isNew = True
        toexcec += '"isNew" = True,'
    if isNew != 'on' and not isNew:
        isNew = False
    isSpecial = request.form.get('special')
    if isSpecial == 'on':
        isSpecial = True
        toexcec += '"isSpecial" = True,'
    if isSpecial != 'on' and not isSpecial:
        isSpecial = False
    isDelite = request.form.get('delite')
    if isDelite == 'on':
        isDelite = True
    if isDelite != 'on' and not isDelite:
        isDelite= False

    price = request.form.get('changeprice')
    value = request.form.get('changevalue')
    data = (price, value, isNew, isSpecial, name)
    if not isDelite:
        cursor.execute("SELECT cost from items WHERE id=%s", (data[4], ))
        oldprice = cursor.fetchall()[0][0]
        data = (price, value, oldprice, name)
        cursor.execute('UPDATE items SET cost = cost + %s, value = value + %s,' + toexcec +
                       'oldprice=%s WHERE id= %s', (data))
        conn.commit()
    else:
        cursor.execute('DELETE FROM items WHERE id=%s', (name, ))
        conn.commit()

    return redirect("/pods")

@app.route('/coils/change/item/', methods=["POST"])
def coils_change():
    if not session['admin']:
        return "У вас нет прав администратора"
    name = request.form.get('name')
    isDelite = request.form.get('delite')
    if isDelite == 'on':
        isDelite = True
    if isDelite != 'on' and not isDelite:
        isDelite = False

    price = request.form.get('changeprice')
    value = request.form.get('changevalue')
    data = (price, value, name)
    if not isDelite:
        cursor.execute('UPDATE coils SET cost = cost + %s, num = num + %s WHERE id= %s', data)
        conn.commit()
    else:
        cursor.execute('DELETE FROM coils WHERE id=%s', (name,))
        conn.commit()
    return redirect("/coils")


@app.route('/sql/<execute>')
def sql(execute):
    if session['admin']:
        cursor.execute(execute)
        if execute[0] == "S":
            response = cursor.fetchall()
        else:
            response = ""
        respa = dict()
        respa["flavour"] = ""
        for i in response:
            respa["flavour"] += str(i[0]) + ","
        return respa


@app.route('/change/item/', methods=["POST"])
def change_item():
    if not session['admin']:
        return "У вас нет прав администратора"
    item_id = request.form.get('name')
    special = not not request.form.get("special")
    new = not not request.form.get("new")
    cat = request.form.get('cat')
    print(item_id, cat, new, special)
    if cat == 'special' and special:
        cursor.execute('UPDATE items set "isSpecial" = False WHERE id = %s', (item_id, ))
        conn.commit()
    elif cat == 'new' and new:
        cursor.execute('UPDATE items set "isNew" = False WHERE id = %s', (item_id, ))
        conn.commit()
    return redirect("/")


@app.route("/getbg/<filename>")
def show_user_profile(filename):
    return send_file(f"backgrounds/{filename}")


@app.route("/server/images/geekvape")
def ret_photo_1():
    return send_file("templates/geekvape-b60-02.jpg", mimetype="image/gif")


@app.route("/server/images/smoant")
def ret_photo_2():
    return send_file("Smoant.jpg", mimetype="image/gif")


@app.route("/server/images/vaporesso")
def ret_photo_3():
    return send_file("Vaporesso.webp", mimetype="image/gif")


@app.route("/server/video/s/bg")
def ret_video():
    return send_file("bg2.mov", mimetype="video")

@app.route("/hookahs")
def hookans():
    cursor.execute("SELECT * FROM items WHERE category = 'hookahs'")
    rows = cursor.fetchall()
    return render_template("hookahs.html", data=rows)
@app.route("/")
def index():
    cursor.execute('SELECT * from items WHERE "isSpecial"')
    records = cursor.fetchall()
    data = [False, False]
    if records:
        for i in records:
            if i[4] > 0:
                data[0] = True
    cursor.execute('SELECT * from items WHERE "isNew"')
    records2 = cursor.fetchall()
    if records2:
        for i in records2:
            if i[4] > 0:
                data[1] = True

    return render_template("main.html", data=data, records2=records2, records=records)


@app.route("/pods", methods=["GET", "POST"])
def pods():
    if request.method == "POST":
        if ";" in request.form.get("sub"):
            return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        toexcecute = (
            f"SELECT * FROM items WHERE category = "
            + "'pods'"
            + f' {request.form.get("sub")}'
        )
        cursor.execute(toexcecute)
        rows = cursor.fetchall()
    else:
        cursor.execute("SELECT * FROM items WHERE category = 'pods'")
        rows = cursor.fetchall()
    cursor.execute("SELECT maker FROM items WHERE category = 'pods'")
    rows2 = cursor.fetchall()
    out = [item for t in rows2 for item in t]

    return render_template("pods.html", data=rows, data2=list(set(out)))


@app.route("/tobacco", methods=["GET", "POST"])
def tobacco():
    if request.method == "GET":
        cursor.execute("SELECT * FROM items WHERE category = 'tobacco'")
        rows = cursor.fetchall()
        dic = dict()
    else:
        if ";" in request.form.get("sub"):
            return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        toexcecute = (
                f"SELECT * FROM items WHERE category = "
                + "'tobacco'"
                + f' {request.form.get("sub")}'
        )
        cursor.execute(toexcecute)

        rows = cursor.fetchall()
        dic = dict()
    print(rows)
    for i in rows:
        if i[0] not in dic.keys():
            dic[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8]))
        else:
            dic[i[0]] += list((i[1], i[4], i[7]))  # price, value and flavour
    dic2 = dict()
    for i in rows:
        if i[0] not in dic2.keys():
            dic2[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8], i[11], i[12]))
    # получить кол-вол элементов с одним названием
    for i in dic.keys():
        dic[i].append((int(len(dic[i][6:]) / 3) + 1))

    tastes = dict()
    for i in dic.keys():
        tastes[i] = [dic[i][4]]
        ell = 5
        for j in range(1, dic[i][-1]):
            ell += 3
            tastes[i] += [dic[i][ell]]

    values = dict()
    for i in dic.keys():
        values[i] = [dic[i][2]]
        ell = 4
        for j in range(1, dic[i][-1]):
            ell += 3
            values[i] += [dic[i][ell]]

    prices = dict()
    for i in dic.keys():
        prices[i] = [dic[i][0]]
        ell = 3
        for j in range(1, dic[i][-1]):
            ell += 3
            prices[i] += [dic[i][ell]]

    res_info = dict()
    for i in dic.keys():
        text = [""]
        if not all(item == 0 for item in values[i]):
            for j in range(0, dic[i][-1]):
                if values[i][j] > 0:
                    text[0] += (
                            f"Вкус - {tastes[i][j]} Цена - {prices[i][j]}, Кол-во на складе - {values[i][j]} "
                            + "@@"
                    )
            res_info[i] = text
        else:
            res_info[i] = ['Нет на складе']

    res_dict = dict()
    for i in dic.keys():
        res_dict[i] = dic2[i] + res_info[i]
    res = []
    for i in res_dict.keys():
        res.append(tuple((i, *list(flatten(res_dict[i])))))
    cursor.execute("SELECT maker FROM items WHERE category = 'tobacco'")
    rows2 = cursor.fetchall()
    out = [item for t in rows2 for item in t]

    return render_template("tobacco.html", data=res, data2=list(set(out)))


@app.route("/<prev>/searchitem")
def search(prev):
    if ";" in request.args["search"]:
        return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
    cursor.execute(
        "SELECT * FROM items WHERE  SIMILARITY(item,%s) > 0.4", (request.args["search"],)
    )
    rows = cursor.fetchall()
    res = rows
    if prev in ["esigs"]:
        dic = dict()
        for i in rows:
            if i[0] not in dic.keys():
                dic[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8]))
            else:
                dic[i[0]] += list((i[1], i[4], i[7]))  # price, value and flavour
        dic2 = dict()
        for i in rows:
            if i[0] not in dic2.keys():
                dic2[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8], i[11], i[12]))
        # получить кол-вол элементов с одним названием
        for i in dic.keys():
            dic[i].append((int(len(dic[i][6:]) / 3) + 1))

        tastes = dict()
        for i in dic.keys():
            tastes[i] = [dic[i][4]]
            ell = 5
            for j in range(1, dic[i][-1]):
                ell += 3
                tastes[i] += [dic[i][ell]]

        values = dict()
        for i in dic.keys():
            values[i] = [dic[i][2]]
            ell = 4
            for j in range(1, dic[i][-1]):
                ell += 3
                values[i] += [dic[i][ell]]

        prices = dict()
        for i in dic.keys():
            prices[i] = [dic[i][0]]
            ell = 3
            for j in range(1, dic[i][-1]):
                ell += 3
                prices[i] += [dic[i][ell]]

        res_info = dict()
        for i in dic.keys():
            text = [""]
            if not all(item == 0 for item in values[i]):
                for j in range(0, dic[i][-1]):
                    if values[i][j] > 0:
                        text[0] += (
                            f"Вкус - {tastes[i][j]} Цена - {prices[i][j]}, Кол-во на складе - {values[i][j]} "
                            + "@@"
                        )
                res_info[i] = text
            else:
                res_info[i] = ['Нет на складе']

        res_dict = dict()
        for i in dic.keys():
            res_dict[i] = dic2[i] + res_info[i]
        res = []
        for i in res_dict.keys():
            res.append(tuple((i, *list(flatten(res_dict[i])))))
    elif prev == 'liq':
        dic = dict()
        for i in rows:
            if i[0] not in dic.keys():
                dic[i[0]] = list((i[1], i[3], i[4], i[7], i[8], i[11], i[15], i[14]))
            else:
                dic[i[0]] += list((i[1], i[4], i[7]))  # price, value and flavour
        dic2 = dict()
        for i in rows:
            if i[0] not in dic2.keys():
                dic2[i[0]] = list((i[1], i[3], i[4], i[7], i[8], i[11], i[15], i[16]))
        # получить кол-вол элементов с одним названием
        for i in dic.keys():
            dic[i].append((int(len(dic[i][6:]) / 3) + 1))

        tastes = dict()
        for i in dic.keys():
            tastes[i] = [dic[i][3]]
            ell = 7
            for j in range(1, dic[i][-1]):
                ell += 3
                tastes[i] += [dic[i][ell]]
        values = dict()
        for i in dic.keys():
            values[i] = [dic[i][2]]
            ell = 6
            for j in range(1, dic[i][-1]):
                ell += 3
                values[i] += [dic[i][ell]]
        prices = dict()
        for i in dic.keys():
            prices[i] = [dic[i][1]]
            ell = 5
            for j in range(1, dic[i][-1]):
                ell += 3
                prices[i] += [dic[i][ell]]

        res_info = dict()
        for i in dic.keys():
            text = [""]
            if not all(item == 0 for item in values[i]):
                for j in range(0, dic[i][-1]):
                    if values[i][j] > 0:
                        text[0] += (
                                f"Вкус - {tastes[i][j]} Цена - {prices[i][j]}, Кол-во на складе - {values[i][j]} "
                                + "@@"
                        )
                res_info[i] = text
            else:
                res_info[i] = ['Нет на складе']

        res_dict = dict()
        for i in dic.keys():
            res_dict[i] = dic2[i] + res_info[i]
        res = []
        for i in res_dict.keys():
            res.append(tuple((i, *list(flatten(res_dict[i])))))
    elif prev == "tobacco":
        dic = dict()
        for i in rows:
            if i[0] not in dic.keys():
                dic[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8]))
            else:
                dic[i[0]] += list((i[1], i[4], i[7]))  # price, value and flavour
        dic2 = dict()
        for i in rows:
            if i[0] not in dic2.keys():
                dic2[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8], i[11], i[12]))
        # получить кол-вол элементов с одним названием
        for i in dic.keys():
            dic[i].append((int(len(dic[i][6:]) / 3) + 1))

        tastes = dict()
        for i in dic.keys():
            tastes[i] = [dic[i][4]]
            ell = 5
            for j in range(1, dic[i][-1]):
                ell += 3
                tastes[i] += [dic[i][ell]]

        values = dict()
        for i in dic.keys():
            values[i] = [dic[i][2]]
            ell = 4
            for j in range(1, dic[i][-1]):
                ell += 3
                values[i] += [dic[i][ell]]

        prices = dict()
        for i in dic.keys():
            prices[i] = [dic[i][0]]
            ell = 3
            for j in range(1, dic[i][-1]):
                ell += 3
                prices[i] += [dic[i][ell]]

        res_info = dict()
        for i in dic.keys():
            text = [""]
            if not all(item == 0 for item in values[i]):
                for j in range(0, dic[i][-1]):
                    if values[i][j] > 0:
                        text[0] += (
                                f"Вкус - {tastes[i][j]} Цена - {prices[i][j]}, Кол-во на складе - {values[i][j]} "
                                + "@@"
                        )
                res_info[i] = text
            else:
                res_info[i] = ['Нет на складе']

        res_dict = dict()
        for i in dic.keys():
            res_dict[i] = dic2[i] + res_info[i]
        res = []
        for i in res_dict.keys():
            res.append(tuple((i, *list(flatten(res_dict[i])))))
    cursor.execute(
        "SELECT maker FROM items WHERE SIMILARITY(item,%s) > 0.4", (request.args.get("search"),)
    )
    rows2 = cursor.fetchall()
    out = [item for t in rows2 for item in t]
    return render_template(f"{prev}.html", data=res, data2=list(set(out)))


@app.route("/esigs", methods=["GET", "POST"])
def esigs():
    if request.method == "GET":
        cursor.execute("SELECT * FROM items WHERE category = 'ashki'")
        rows = cursor.fetchall()
        dic = dict()
    else:
        if ";" in request.form.get("sub"):
            return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        toexcecute = (
            f"SELECT * FROM items WHERE category = "
            + "'ashki'"
            + f' {request.form.get("sub")}'
        )
        cursor.execute(toexcecute)

        rows = cursor.fetchall()
        dic = dict()
    for i in rows:
        if i[0] not in dic.keys():
            dic[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8]))
        else:
            dic[i[0]] += list((i[1], i[4], i[7]))  # price, value and flavour
    dic2 = dict()
    for i in rows:
        if i[0] not in dic2.keys():
            dic2[i[0]] = list((i[1], i[3], i[4], i[6], i[7], i[8], i[11], i[12]))
    # получить кол-вол элементов с одним названием
    for i in dic.keys():
        dic[i].append((int(len(dic[i][6:]) / 3) + 1))

    tastes = dict()
    for i in dic.keys():
        tastes[i] = [dic[i][4]]
        ell = 5
        for j in range(1, dic[i][-1]):
            ell += 3
            tastes[i] += [dic[i][ell]]

    values = dict()
    for i in dic.keys():
        values[i] = [dic[i][2]]
        ell = 4
        for j in range(1, dic[i][-1]):
            ell += 3
            values[i] += [dic[i][ell]]

    prices = dict()
    for i in dic.keys():
        prices[i] = [dic[i][0]]
        ell = 3
        for j in range(1, dic[i][-1]):
            ell += 3
            prices[i] += [dic[i][ell]]

    res_info = dict()
    for i in dic.keys():
        text = [""]
        if not all(item == 0 for item in values[i]):
            for j in range(0, dic[i][-1]):
                if values[i][j] > 0:
                    text[0] += (
                            f"Вкус - {tastes[i][j]} Цена - {prices[i][j]}, Кол-во на складе - {values[i][j]} "
                            + "@@"
                    )
            res_info[i] = text
        else:
            res_info[i] = ['Нет на складе']

    res_dict = dict()
    for i in dic.keys():
        res_dict[i] = dic2[i] + res_info[i]
    res = []
    for i in res_dict.keys():
        res.append(tuple((i, *list(flatten(res_dict[i])))))
    cursor.execute("SELECT maker FROM items WHERE category = 'ashki'")
    rows2 = cursor.fetchall()
    out = [item for t in rows2 for item in t]

    return render_template("esigs.html", data=res, data2=list(set(out)))


@app.route("/liq", methods=['POST', 'GET'])
def liq():
    if request.method == "GET":
        cursor.execute("SELECT * FROM items WHERE category = 'liq'")
        rows = cursor.fetchall()
        dic = dict()
    else:
        if ";" in request.form.get("sub"):
            return redirect("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        toexcecute = (
                f"SELECT * FROM items WHERE category = "
                + "'liq'"
                + f' {request.form.get("sub")}'
        )
        cursor.execute(toexcecute)

        rows = cursor.fetchall()
        dic = dict()
    for i in rows:
        if i[0] not in dic.keys():
            dic[i[0]] = list((i[1], i[3], i[4], i[7], i[8], i[11], i[15], i[14]))
        else:
            dic[i[0]] += list((i[1], i[4], i[7]))  # price, value and flavour
    dic2 = dict()
    for i in rows:
        if i[0] not in dic2.keys():
            dic2[i[0]] = list((i[1], i[3], i[4], i[7], i[8], i[11], i[15], i[16]))
    # получить кол-вол элементов с одним названием
    for i in dic.keys():
        dic[i].append((int(len(dic[i][6:]) / 3) + 1))

    tastes = dict()
    for i in dic.keys():
        tastes[i] = [dic[i][3]]
        ell = 7
        for j in range(1, dic[i][-1]):
            ell += 3
            tastes[i] += [dic[i][ell]]
    values = dict()
    for i in dic.keys():
        values[i] = [dic[i][2]]
        ell = 6
        for j in range(1, dic[i][-1]):
            ell += 3
            values[i] += [dic[i][ell]]
    prices = dict()
    for i in dic.keys():
        prices[i] = [dic[i][1]]
        ell = 5
        for j in range(1, dic[i][-1]):
            ell += 3
            prices[i] += [dic[i][ell]]

    res_info = dict()
    for i in dic.keys():
        text = [""]
        if not all(item == 0 for item in values[i]):
            for j in range(0, dic[i][-1]):
                if values[i][j] > 0:
                    text[0] += (
                            f"Вкус - {tastes[i][j]} Цена - {prices[i][j]}, Кол-во на складе - {values[i][j]} "
                            + "@@"
                    )
            res_info[i] = text
        else:
            res_info[i] = ['Нет на складе']

    res_dict = dict()
    for i in dic.keys():
        res_dict[i] = dic2[i] + res_info[i]
    res = []
    for i in res_dict.keys():
        res.append(tuple((i, *list(flatten(res_dict[i])))))
    cursor.execute("SELECT maker FROM items WHERE category = 'liq'")
    rows2 = cursor.fetchall()
    out = [item for t in rows2 for item in t]
    return render_template("liq.html", data=res, data2 = set(out))

@app.route("/liq/filters", methods=["POST"])
def liq2():
    data = request.json
    data["price"] = f'cost > {data["minPrice"]} AND cost < {data["maxPrice"]}'
    data["maxPrice"], data["minPrice"] = "All", "All"
    filter_item = ""
    had_puffs_already = False
    for i in data.keys():
        if data[i] != "All":
            if not had_puffs_already and "mg" in str(data[i]):
                had_puffs_already = True
                filter_item += f"AND ({data[i]})"
            elif "mg" in str(data[i]) and had_puffs_already:
                filter_item += f"OR ({data[i]} )"
            else:
                filter_item += f"AND ({data[i]} )"
    return filter_item


@app.route("/esigs/filters", methods=["POST"])
def esigs2():
    data = request.json
    data["price"] = f'cost > {data["minPrice"]} AND cost < {data["maxPrice"]}'
    data["maxPrice"], data["minPrice"] = "All", "All"
    filter_item = ""
    had_puffs_already = False
    for i in data.keys():
        if data[i] != "All":
            if not had_puffs_already and "puffs" in str(data[i]):
                had_puffs_already = True
                filter_item += f"AND ({data[i]})"
            elif "puffs" in str(data[i]) and had_puffs_already:
                filter_item += f"OR ({data[i]} )"
            else:
                filter_item += f"AND ({data[i]} )"
    return filter_item


@app.route("/pods/filters", methods=["POST"])
def pods2():
    data = request.json
    data["price"] = f'cost > {data["minPrice"]} AND cost < {data["maxPrice"]}'
    data["maxPrice"], data["minPrice"] = "All", "All"
    filter_item = ""
    had_puffs_already = False
    for i in data.keys():
        if data[i] != "All":
            if not had_puffs_already and "maxw" in str(data[i]):
                had_puffs_already = True
                filter_item += f"AND ({data[i]})"
            elif "maxw" in str(data[i]) and had_puffs_already:
                filter_item += f"OR ({data[i]} )"
            else:
                filter_item += f"AND ({data[i]} )"
    return filter_item


@app.route("/coils")
def coils():
    cursor.execute("SELECT maker FROM coils")
    rows = cursor.fetchall()
    return render_template("coils.html", data=rows, put="Aegis Boost Pro")


@app.route("/pod", methods=["POST"])
def postcoiils():
    device = request.form.get("device", None)
    cursor.execute("SELECT * FROM coils")
    rows = cursor.fetchall()
    for i in rows:
        j = i[5].split(", ")
        for s in j:
            if SequenceMatcher(a=s,b=device).ratio() > 0.6:
                print(i[0])
                cursor.execute("SELECT * FROM coils WHERE similarity(name, %s) > 0.5", [str(i[0])])
                data = cursor.fetchall()
                return render_template("coils2.html", data=data)
    return render_template("coils.html", put="Ничего не найдено попробуйте еще раз")


if __name__ == "__main__":
    app.run(port=4567, debug=True, host="0.0.0.0")
    conn.close()
