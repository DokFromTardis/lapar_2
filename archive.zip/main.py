import psycopg2
from datetime import datetime
import telebot
from telebot import types
import pandas as pd


def download_image(message, name):
    fileid = message.photo[-1].file_id
    file_info = bot.get_file(fileid)
    downloaded_file = bot.download_file(file_info.file_path)
    with open(f'{name}.jpg', 'wb') as new_file:
        new_file.write(downloaded_file)


last_messages = {}
ashkas_dict = {}
pod_dict = {}  
liq_dict = {}  
bot = telebot.TeleBot('5939134977:AAF4489xx0Uza7XrYZAlEpR0gWeYM8OSJ_U')


conn = psycopg2.connect(dbname='lapar', user='dok', 
                        password='34686V', host='localhost')
cursor = conn.cursor()
nospecials = True

class newAshka:
    def __init__(self, maker):
        self.name = None
        self.cost = None
        self.maker = maker
        self.puffs = None
        self.num = None
        self.flavours = None


class newPod:
    def __init__(self, maker):
        self.name = None
        self.cost = None
        self.maker = maker
        self.num = None
        self.path = None


class newLiq:
    def __init__(self, maker):
        self.name = None                                                                      
        self.cost = None                                                                      
        self.maker = maker                                                                    
        self.num = None 
        self.ml = None
        self.flavour = None


markup = types.InlineKeyboardMarkup(row_width=1)
itembtn1 = types.InlineKeyboardButton(text='Одноразовые сигареты', callback_data='item_ashki')
itembtn2 = types.InlineKeyboardButton('Под-системы', callback_data='item_pods')
itembtn3 = types.InlineKeyboardButton('Жидкости', callback_data='item_liq')
itembtn4 = types.InlineKeyboardButton('Испарители', callback_data='item_coils')
itembtn5 = types.InlineKeyboardButton('Табак', callback_data='item_tobacco')
itembtn6 = types.InlineKeyboardButton('Кальяны', callback_data='item_hookahs')
markup.add(itembtn1, itembtn2, itembtn3, itembtn4, itembtn5, itembtn6)


def get_maker_pod(message):
    pod = newPod(message.text)                                                            
    pod_dict[message.chat.id] = pod                                                  
    msg = bot.reply_to(message, 'Введите название устройства:')                           
    bot.register_next_step_handler(msg, get_name_pod)   


def get_name_pod(message):
    pod = pod_dict[message.chat.id]
    pod.name = message.text
    msg = bot.reply_to(message, 'Введите цену:')                                        
    bot.register_next_step_handler(msg, get_cost_pod)   


def get_cost_pod(message):                                                                   
    pod = pod_dict[message.chat.id]                                                           
    pod.cost = message.text                                                                   
    msg = bot.reply_to(message, 'Отправьте картинку товара:')
    bot.register_next_step_handler(msg, get_pic_pod) 


def get_pic_pod(message):                                                                                       
    pod = pod_dict[message.chat.id]                                                                              
    pod.path = pod.name + ".jpg"
    download_image(message, pod.name)
    msg = bot.reply_to(message, 'Введите количество товара:')                                                    
    bot.register_next_step_handler(msg, get_num_pod)   


def get_num_pod(message):
    pod = pod_dict[message.chat.id]                                                           
    pod.num = message.text
    data = (pod.maker, pod.name, "pods", pod.cost, pod.num, False, pod.path)
    cursor.execute('INSERT INTO items  (maker, item, category, cost, value, "isSpecial", path) VALUES(%s,%s,%s,%s,%s,%s, %s)', data)                                       
    conn.commit()                                                                         
    bot.send_message(message.chat.id, "Успешно") 


def get_maker_ashki(message):
    ashka = newAshka(message.text)
    ashkas_dict[message.chat.id] = ashka
    msg = bot.reply_to(message, 'Введите количество\n Например: Есть по пять электронных сигарет на каждый вкус. В таком случае на этот вопрос надо ответить 5.')
    bot.register_next_step_handler(msg, get_num_ashki)


def get_num_ashki(message):
    ashka = ashkas_dict[message.chat.id]
    ashka.num = int(message.text)
    msg = bot.reply_to(message, 'Введите название:')
    bot.register_next_step_handler(msg, get_name_ashki)     


def get_name_ashki(message):
    ashka = ashkas_dict[message.chat.id]
    ashka.name = message.text
    msg = bot.reply_to(message, 'Введите количество затяжек:')
    bot.register_next_step_handler(msg, get_puffs_ashki)


def get_puffs_ashki(message):
    ashka = ashkas_dict[message.chat.id]                                                      
    ashka.puffs = message.text
    msg = bot.reply_to(message, 'Введите цену:')                                
    bot.register_next_step_handler(msg, get_picture_ashki)


def get_flavours_ashki(message):
    ashka = ashkas_dict[message.chat.id]
    download_image(message, ashka.name)
    msg = bot.reply_to(message, 'Введите доступные вкусы через запятую\nНапример: Клубника,Манго-маракуя, Черная смородина...')
    bot.register_next_step_handler(msg, finish_ashku)


def get_picture_ashki(message):
    ashka = ashkas_dict[message.chat.id]
    ashka.cost = message.text
    msg = bot.reply_to(message, 'Отправьте картинку товара')
    bot.register_next_step_handler(msg, get_flavours_ashki)


def finish_ashku(message):
    ashka = ashkas_dict[message.chat.id]
    flavours = message.text.split(",")
    for i in flavours:
        data = (ashka.name, ashka.cost, "ashki", ashka.maker, ashka.num, False,  ashka.puffs, i, ashka.name + ".jpg")
        cursor.execute('INSERT INTO items  (item, cost, category, maker, value, "isSpecial", puffs, flavour, path) VALUES(%s,%s,%s,%s,%s,%s,%s, %s, %s)', data)
        conn.commit() 
    bot.send_message(message.chat.id, "Успешно")


def get_maker_coil(message):
    bot.send_message(message.chat.id, "Для вашего устройства на складе есть: \n 0.3 ома - 5 штук 450 рублей\n0.4 ома - 2 штуки 450 рублей\n0.6 ом - Нет в наличии")


def get_new_price(message, data):
    if 'flavour' in data:
        cursor.execute('SELECT * FROM items  WHERE item = %s AND flavour = %s', (data.split("_")[3], data.split("_")[4].split("=")[1],))
        records = cursor.fetchall()
        cursor.execute("UPDATE items SET cost = %s WHERE item= %s AND flavour = %s", (message.text, data.split("_")[3], data.split("_")[4].split("=")[1]))
        conn.commit()
        if records[0][1] > int(message.text):
            cursor.execute('UPDATE items SET "isSpecial" = True WHERE item= %s AND flavour = %s', (data.split("_")[3], data.split("_")[4].split("=")[1]))
            conn.commit()
            cursor.execute('UPDATE items SET oldprice = %s WHERE item= %s and flavour = %s', (message.text, data.split("_")[3], data.split("_")[4].split("=")[1]))
            conn.commit()
    else:
        cursor.execute('SELECT * FROM items  WHERE item = %s', (data.split("_")[3],))
        records = cursor.fetchall()
        cursor.execute("UPDATE items SET cost = %s WHERE item= %s", (message.text, data.split("_")[3], ))
        conn.commit()
        if records[0][1] > int(message.text):
            cursor.execute('UPDATE items SET "isSpecial" = True WHERE item= %s', (data.split("_")[3],))
            conn.commit()
            cursor.execute('UPDATE items SET oldprice = %s WHERE item= %s', (message.text, data.split("_")[3],))
            conn.commit()
    bot.send_message(chat_id=message.chat.id, text='Успешно!')


@bot.callback_query_handler(func=lambda call: True)
def callback_worker(call):
    global nospecials, markup
    cursor.execute('SELECT "isSpecial" FROM items')
    records = cursor.fetchall()
    for i in records:
        if i[0] == True:
            if nospecials:
                nospecials = False
                markup.add(types.InlineKeyboardButton("🔥Горячие предложения", callback_data="specials"))
        else:
            nospecials = True
            markup = types.InlineKeyboardMarkup(row_width=1)
            itembtn1 = types.InlineKeyboardButton(text='Одноразовые сигареты', callback_data='item_ashki')
            itembtn2 = types.InlineKeyboardButton('Под-системы', callback_data='item_pods')
            itembtn3 = types.InlineKeyboardButton('Жидкости', callback_data='item_liq')
            itembtn4 = types.InlineKeyboardButton('Испарители', callback_data='item_coils')
            itembtn5 = types.InlineKeyboardButton('Табак', callback_data='item_tobacco')
            itembtn6 = types.InlineKeyboardButton('Кальяны', callback_data='item_hookahs')
            markup.add(itembtn1, itembtn2, itembtn3, itembtn4, itembtn5, itembtn6)
    who = call.message.chat.id
    if call.data == "specials":
        cursor.execute('SELECT * FROM items  WHERE "isSpecial"= True')
        rec = cursor.fetchall()
        for records in rec:
            img = open(f'backgrounds/{records[0][8]}', 'rb')
            items = types.InlineKeyboardMarkup()
            if records[2] == "pods":
                if call.message.chat.id == 349488720:
                    a = types.InlineKeyboardButton("Убрать из горячих предложений",
                                                   callback_data=f'item_{records[2]}_{records[3]}_{records[0]}_despecial')
                    items.add(a)
                bot.send_photo(call.message.chat.id, img,
                               f'Название:{records[0]}\nПроизводитель:{records[3]}\nЦена:{records[1]}\nКоличество на складе: {records[4]}',
                               reply_markup=items)
            elif records[2] == "ashki":
                if call.message.chat.id == 349488720:
                    a = types.InlineKeyboardButton("Убрать из горячих предложений",
                                                   callback_data=f'item_{records[2]}_{records[3]}_{records[0]}_flavour={records[7]}_despecial')
                    items.add(a)
                    bot.send_photo(call.message.chat.id, img,
                                   f'Название:{records[0]}\nПроизводитель:{records[3]}\nЦена:{records[1]}\nКоличество на складе: {records[4]}\nКоличество затяжек: {records[6]}\nВкус: {records[7]}',
                                   reply_markup=items)
    if call.data.split("_")[0] == "add":
        a = [f'get_maker_{call.data.split("_")[1]}']
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=last_messages[call.message.chat.id].id,
                              text='Выберите производителя:')
        bot.register_next_step_handler(call.message, eval(f'get_maker_{call.data.split("_")[1]}'))
    elif call.data.split("_")[0] == "item":
        if call.data == 'item':
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=last_messages[call.message.chat.id].id,
                                  text=f'Привет, {call.message.from_user.first_name if type(call.message.from_user.first_name) != type(None) else ""} {call.message.from_user.last_name if type(call.message.from_user.last_name) != type(None) else ""}! Я бот-помощник магазина La Par. Здесь ты можешь посмотреть товары, которые сейчас в наличии, а также их цену.\nТаллинская д.18, -1 этаж', reply_markup=markup)
        if len(call.data.split("_")) == 2:
            cursor.execute('SELECT maker FROM items WHERE category = %s', (call.data.split("_")[1], ))
            records = cursor.fetchall()
            button_list = []
            for each in list(set(records)):
                each = each[0]
                button_list.append(types.InlineKeyboardButton(each, callback_data=f'item_{call.data.split("_")[1]}_{each}'))
            items = types.InlineKeyboardMarkup(row_width=1)
            items.add(*button_list) if button_list != [] else print()
            items.add(types.InlineKeyboardButton("Назад ◀️", callback_data=f'{"_".join(call.data.split("_")[:len(call.data.split("_")) - 1])}'))
            if call.message.chat.id == 349488720:
                items.add(types.InlineKeyboardButton("Добавить ➕", callback_data=f'add_{call.data.split("_")[1]}'))
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=last_messages[call.message.chat.id].id,
                                  text='Выберите производителя:', reply_markup=items)
        elif len(call.data.split("_")) == 3:
            print(call.data)
            cursor.execute('SELECT item FROM items WHERE maker = %s AND category = %s', (call.data.split("_")[2], call.data.split("_")[1], ))
            records = cursor.fetchall()
            button_list = []
            for each in list(set(records)):
                each = each[0]
                button_list.append(types.InlineKeyboardButton(each, callback_data=f'item_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{each}'))
            items = types.InlineKeyboardMarkup(row_width=1)
            items.add(*button_list) if button_list != [] else print("")
            items.add(types.InlineKeyboardButton("Назад ◀️",
                                                 callback_data=f'{"_".join(call.data.split("_")[:len(call.data.split("_")) - 1])}'))
            if call.message.chat.id == 349488720:
                items.add(types.InlineKeyboardButton("Добавить ➕", callback_data=f'add_{call.data.split("_")[1]}'))
            bot.edit_message_text(chat_id=call.message.chat.id, message_id=last_messages[call.message.chat.id].id,
                                  text='Выберите название:', reply_markup=items)
        elif len(call.data.split("_")) == 4:
            cursor.execute('SELECT * FROM items  WHERE item = %s', (call.data.split("_")[3], ))
            records = cursor.fetchall()
            img = open(f'backgrounds/{records[0][8]}', 'rb')
            if call.message.chat.id == 349488720:
                a = types.InlineKeyboardButton("Пополнить количество", callback_data=f'item_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_+')
                b = types.InlineKeyboardButton("Убавить количество", callback_data=f'item_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_sell')
                c = types.InlineKeyboardButton("Изменить цену", callback_data=f'item_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_price')
                items = types.InlineKeyboardMarkup(row_width=1)
                items.add(a, b, c)
            else:
                items = types.InlineKeyboardMarkup(row_width=1)
            if call.data.split("_")[1] in ["pods", "hookahs"]:
                bot.send_photo(call.message.chat.id, img, f'Название:{records[0][0]}\nПроизводитель:{records[0][3]}\nЦена:{records[0][1]}\nКоличество на складе: {records[0][4]}', reply_markup=items)
            elif call.data.split("_")[1] == "ashki" or call.data.split("_")[1] == "tobacco" or call.data.split("_")[1] == "liq":
                cursor.execute('SELECT flavour FROM items WHERE item = %s', (call.data.split("_")[3],))
                records = cursor.fetchall()
                button_list = []
                for each in list(set(records)):
                    each = each[0]
                    print(f'i_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{call.data.split("_")[3]}_flav={each}')
                    button_list.append(
                        types.InlineKeyboardButton(each, callback_data=f'i_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{call.data.split("_")[3]}_flav={each}'))
                items = types.InlineKeyboardMarkup(row_width=1)
                items.add(*button_list) if button_list != [] else print()
                items.add(types.InlineKeyboardButton("Назад ◀️",
                                                     callback_data=f'{"_".join(call.data.split("_")[:len(call.data.split("_")) - 1])}'))
                bot.edit_message_text(chat_id=call.message.chat.id, message_id=last_messages[call.message.chat.id].id,
                                      text='Выберите вкус:', reply_markup=items)
        elif len(call.data.split("_")) == 5:
            if call.data.split("_")[4] == '+':
                pass
            elif call.data.split("_")[4] == 'sell':
                cursor.execute("UPDATE items SET value = value-1 WHERE item= %s", (call.data.split("_")[3], ))
                conn.commit()
                cursor.execute('SELECT * FROM items  WHERE item = %s', (call.data.split("_")[3], ))
                records = cursor.fetchall()
                cursor.execute('INSERT INTO sells (category, cost, "when") VALUES (%s,%s,%s)', (call.data.split("_")[1], records[0][1], datetime.now()))
                last_messages[who] = bot.send_message(call.message.chat.id,
                                                      f'Успешно, количество сейчас {records[0][4]}')
            elif call.data.split("_")[4] == 'price':
                msg = bot.send_message(call.message.chat.id,f'Введите новую цену')
                bot.register_next_step_handler(msg, get_new_price, call.data)
            elif call.data.split("_")[4] == 'despecial':
                cursor.execute('UPDATE items SET "isSpecial" = False WHERE item= %s', (call.data.split("_")[3],))
                conn.commit()
                bot.send_message(call.message.chat.id, "Успешно")
            elif "flav" in call.data.split("_")[4]:
                flavour = call.data.split("_")[4].split("=")[1]
                print(call.data)
                print(call.data.split("_")[3], flavour)
                cursor.execute('SELECT * FROM items  WHERE item = %s AND flavour = %s', (call.data.split("_")[3], flavour))
                records = cursor.fetchall()
                print(records)
                img = open(f'backgrounds/{records[0][8]}', 'rb')
                if call.message.chat.id == 349488720:
                    a = types.InlineKeyboardButton("Пополнить количество",
                                                   callback_data=f'item_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_+')
                    b = types.InlineKeyboardButton("Убавить количество",
                                                   callback_data=f'item_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_flavour={flavour}_sell')
                    c = types.InlineKeyboardButton("Изменить цену",
                                                   callback_data=f'item_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_flavour={flavour}_price')
                    items = types.InlineKeyboardMarkup(row_width=1)
                    items.add(a, b, c)
                else:
                    items = types.InlineKeyboardMarkup(row_width=1)
                bot.send_photo(call.message.chat.id, img,
                               f'Название:{records[0][0]}\nПроизводитель:{records[0][3]}\nЦена:{records[0][1]}\nКоличество на складе: {records[0][4]}\nКоличество Затяжек: {records[0][6]},\nВкус: {flavour}',
                               reply_markup=items)
        elif len(call.data.split("_")) == 6:
            if 'flavour' in call.data:

                if "sell" in call.data:
                    cursor.execute("UPDATE items SET value = value-1 WHERE item= %s AND flavour = %s", (call.data.split("_")[3], call.data.split("_")[4].split("=")[1]))
                    conn.commit()
                    cursor.execute('SELECT * FROM items  WHERE item = %s AND flavour = %s', (call.data.split("_")[3],call.data.split("_")[4].split("=")[1]))
                    records = cursor.fetchall()
                    cursor.execute('INSERT INTO sells (category, cost, "when") VALUES (%s,%s,%s)',
                                   (call.data.split("_")[1], records[0][1], datetime.now()))
                    last_messages[who] = bot.send_message(call.message.chat.id,
                                                          f'Успешно, количество сейчас {records[0][4]}')
                if "price" in call.data:
                    msg = bot.send_message(call.message.chat.id, f'Введите новую цену')
                    bot.register_next_step_handler(msg, get_new_price, call.data)
                if 'despecial' in call.data:
                    cursor.execute('UPDATE items SET "isSpecial" = False WHERE item= %s AND flavour = %s', (call.data.split("_")[3],call.data.split("_")[4].split("=")[1]))
                    conn.commit()
                    bot.send_message(call.message.chat.id, "Успешно")
    elif call.data[0] == 'i':
        if len(call.data.split("_")) == 5:
            flavour = call.data.split("_")[4].split("=")[1]
            cursor.execute('SELECT * FROM items  WHERE item = %s AND flavour = %s', (call.data.split("_")[3], flavour))
            records = cursor.fetchall()
            print(f'i_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_flav={flavour}')
            img = open(f'backgrounds/{records[0][8]}', 'rb')
            if call.message.chat.id == 349488720:
                a = types.InlineKeyboardButton("Пополнить количество",
                                               callback_data=f'i_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_f={flavour}_+')
                b = types.InlineKeyboardButton("Убавить количество",
                                               callback_data=f'i_{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_f={flavour}_s')
                c = types.InlineKeyboardButton("Изменить цену",
                                               callback_data=f'i__{call.data.split("_")[1]}_{call.data.split("_")[2]}_{records[0][0]}_f={flavour}_price')
                items = types.InlineKeyboardMarkup(row_width=1)
                items.add(a, b, c)
            else:
                items = types.InlineKeyboardMarkup(row_width=1)
            bot.send_photo(call.message.chat.id, img,
                           f'Название:{records[0][0]}\nПроизводитель:{records[0][3]}\nЦена:{records[0][1]}\nКоличество на складе: {records[0][4]}\nКоличество Затяжек: {records[0][6]},\nВкус: {flavour}',
                           reply_markup=items)
        elif  len(call.data.split("_")) == 6:
            print(call.data.split("_"))
            if  call.data.split("_")[4].split("=")[0] == "f":
                if call.data.split("_")[5] == "s":
                    cursor.execute("UPDATE items SET value = value-1 WHERE item= %s AND flavour = %s",
                                   (call.data.split("_")[3], call.data.split("_")[4].split("=")[1]))
                    conn.commit()
                    cursor.execute('SELECT * FROM items  WHERE item = %s AND flavour = %s',
                                   (call.data.split("_")[3], call.data.split("_")[4].split("=")[1]))
                    records = cursor.fetchall()
                    print('SELECT * FROM items  WHERE item = %s AND flavour = %s',
                                   (call.data.split("_")[2], call.data.split("_")[4].split("=")[1]))
                    cursor.execute('INSERT INTO sells (category, cost, "when") VALUES (%s,%s,%s)',
                                   (call.data.split("_")[1], records[0][1], datetime.now()))
                    print(call.data.split("_")[1])
                    conn.commit()
                    bot.send_message(call.message.chat.id,
                                                          f'Успешно, количество сейчас {records[0][4]}')



@bot.message_handler(content_types=['text'])
def get_text_messages(message):
    global markup
    who = message.chat.id
    if message.text == "/start":
        global nospecials
        cursor.execute('SELECT "isSpecial" FROM items')
        records = cursor.fetchall()
        for i in records:
            if i[0] == True:
                if nospecials:
                    nospecials = False
                    markup.add(types.InlineKeyboardButton("🔥Горячие предложения", callback_data="specials"))
                else:
                    markup = types.InlineKeyboardMarkup(row_width=1)
                    itembtn1 = types.InlineKeyboardButton(text='Одноразовые сигареты', callback_data='item_ashki')
                    itembtn2 = types.InlineKeyboardButton('Под-системы', callback_data='item_pods')
                    itembtn3 = types.InlineKeyboardButton('Жидкости', callback_data='item_liq')
                    itembtn4 = types.InlineKeyboardButton('Испарители', callback_data='item_coils')
                    itembtn5 = types.InlineKeyboardButton('Табак', callback_data='item_tobacco')
                    itembtn6 = types.InlineKeyboardButton('Кальяны', callback_data='item_hookahs')
                    markup.add(itembtn1, itembtn2, itembtn3, itembtn4, itembtn5, itembtn6)
        if message.chat.id == 349488720:
            keyboard = types.ReplyKeyboardMarkup()
            keyboard.add("Информация о заработке", "Руководство по управлению ботом")
            bot.send_message(message.chat.id, "У вас есть права администратора в боте", reply_markup=keyboard)
        last_messages[who] = bot.send_message(message.chat.id, f"Привет, {message.from_user.first_name if type(message.from_user.first_name) != type(None) else ''} {message.from_user.last_name if type(message.from_user.last_name) != type(None) else ''}! Я бот-помощник магазина La Par. Здесь ты можешь посмотреть товары, которые сейчас в наличии, а также их цену.\nТаллинская д.18, -1 этаж", reply_markup=markup)
    if message.text == "Информация о заработке":
        df = pd.read_sql("SELECT * from sells", conn)
        a = datetime.now()
        df.to_excel(f'{a}.xlsx')
        f = open(f'{a}.xlsx', "rb")
        bot.send_document(message.chat.id, f)


while True:
    # try:
    bot.polling(none_stop=True, interval=0)
    # except Exception as e:
    #     print(e)
conn.close()
print(" connection with database is closed")